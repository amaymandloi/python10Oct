 
the_names = ["Amay", "Raj", "Aishwary", "Atharv", "Anshul", "Avinash", "Amay", "Raj", "Balram", "Romil"]  
  
# Converting the above list to the set  
the_unique_names = set( the_names)  
  

print( the_unique_names)  