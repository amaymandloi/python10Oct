list_1 = [1, 2, 1, 4, 6]

print(list(set(list_1)))