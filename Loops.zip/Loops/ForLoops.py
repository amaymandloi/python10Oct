fruits = ["apple", "banana", "cherry","kiwi","Grappes","Orange"]
for x in fruits:
  print(x)