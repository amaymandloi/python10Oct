class Employee:
    def __init__(self, name, salary, company, Mobile_Number):
       
        self.name = name
        self.salary = salary
        self.company = company
        self.Mobile_Number = Mobile_Number
        
        

    def show(self):
        print("Name is ", self.name, "salary is", self.salary, " company_Name is",self.company, "and Mobile_Number is ", self.Mobile_Number)

emp = Employee("Amay_Mandloi", 40000, "yash Technologies",7247524663)
emp.show()

emp2 = Employee("Akshat_Mandloi", 45000, "infobeans", 7723862338)
emp2.show()

print(emp.salary)
print(emp.Mobile_Number)
print(emp2.Mobile_Number)
print(emp2.salary)